# Web-based data analysis
## Example: Students' Academic Performance Dataset
### Technologies: React and Redux
#### Author: Ho Seok (Brandon) Oh

## [Demo](https://students-performance-hoseokoh.herokuapp.com/)

> I am using [Students' Academic Performance Dataset](https://www.kaggle.com/aljarah/xAPI-Edu-Data) in [Kaggle](https://www.kaggle.com/) Datasets.

#### Objectives
- Understanding of React and Redux
- Converting CSV file to JSON
- Implementing an open source chart library - [Chart.js](https://www.chartjs.org/)
- Using Frontend stylesheet libraries - [Bootstrap](https://react-bootstrap.github.io/), [Font Awesome](https://fontawesome.com/), [SASS](https://github.com/michaelwayman/node-sass-chokidar#readme)


> Before implementing this web application, I first try to anlayze this dataset on a Jupyter notebook with Python and [scikit-learn](https://scikit-learn.org/stable/) to check whether missing values exist and to understand several features. Also, I perform Machine Learning algorithms to get more important features.


#### How to convert CSV file to JSON
```
$ node csvToJson.js
```

> I've already converted CSV file to JSON called **students.json** which is located in the public folder.


#### To start


1. Go to the folder

```
$ cd students-academic-performance
```

2. Install npm packages

```
$ npm install
```

3. Start

```
$ npm start
```
