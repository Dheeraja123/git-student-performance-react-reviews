import React from 'react';
import { Row, Col } from 'react-bootstrap';

import Header from './Header';
import Jumbotron from './Jumbotron';


const Landing = () => (
  <div className="landing">
    <Header />
    <Jumbotron />

    <section className="container main">

      <section className="greeting">
        <div className="comment success">
          <h2 className="title">
            <i className="far fa-smile-wink"></i> Greetings
          </h2>
          
          <p className="message">
            Thank you for visiting this website.<br /> 
            This sample web-based application contains some information and several charts in terms of the educational dataset in <a href='https://www.kaggle.com/aljarah/xAPI-Edu-Data/home'>Kaggle Datasets</a>.
          </p>
        </div>
      </section>


    </section>
    
  </div>
);

export default Landing;