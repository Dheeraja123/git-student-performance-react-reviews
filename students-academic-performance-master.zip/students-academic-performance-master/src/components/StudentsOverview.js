import React from 'react';
import { Panel } from 'react-bootstrap';
import Datatable from 'react-bs-datatable';
import PropTypes from 'prop-types';

import IntroPage from './IntroPage';
import Note from './Note';
import { getByGender, getByNationality } from '../reducers/students';
import { countryRenames } from '../utils/rename';
import { header, customLabels } from '../utils/dataTable';

class StudentsOverview extends React.Component {

  render() {
    const { students } = this.props.childProps;

    const byGender = getByGender(students.all);
    const byNationality = getByNationality(students.all);

    // get nationality info
    let nationalityInfo = [];
    for (let nationality in byNationality) {
      let countryName = nationality.charAt(0).toUpperCase() + nationality.slice(1);
      const numStudents = byNationality[nationality].length;
      
      // Change a country name
      if ( countryRenames[countryName] !== undefined ) {
        countryName = countryRenames[countryName];
      }

      if (numStudents === 1) {
        nationalityInfo.push(`${ numStudents } student are from ${ countryName }`);
      } else {
        nationalityInfo.push(`${ numStudents } students are from ${ countryName }`);
      }
    }

    return (
      <div className="students-overview">
        <IntroPage menu={{
          "title": "Students' Overview",
          "navi": [
            { "name": "Home", "path": "/" },
            { "name": "Students' Overview", "path": null }
          ]
        }} />
      
        <div className="container overview-wrapper">

          <section>
            <h3>List of students</h3>
            <Datatable
              tableHeader={header}
              tableBody={ students.all }
              keyName="studentsTable"
              tableClass="striped hover responsive"
              rowsPerPage={20}
              rowsPerPageOption={[20, 40, 80, 100]}
              initialSort={{ prop: "LastName", isAscending: true }}
              labels={customLabels}
            />
          </section>

        </div>
      </div>
    );
  }
}

StudentsOverview.propTypes = {
  childProps: PropTypes.shape({
    students: PropTypes.object.isRequired
  }).isRequired
};

export default StudentsOverview;