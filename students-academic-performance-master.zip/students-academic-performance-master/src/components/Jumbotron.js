import React from 'react';
import { Link } from 'react-router-dom';

const Jumbotron = () => (
  <section className="container-fluid">
    <div className="jumbotron-wrapper">
      
      <div className="content">
        <h1>Students' Academic Performance Dataset</h1>
        
   
        
        <h3>
          <a href='https://www.kaggle.com/aljarah/xAPI-Edu-Data/home'>in Kaggle Datasets</a>
        </h3>
        
        <Link to='/students'>Get Students' Information</Link>
      </div>

    </div>
  </section>
);

export default Jumbotron;
